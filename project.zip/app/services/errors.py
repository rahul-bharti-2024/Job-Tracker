class NotFoundError(Exception):
    pass

class DuplicateError(Exception):
    pass

class InvalidTransitionError(Exception):
    pass

