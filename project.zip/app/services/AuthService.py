import logging

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.security import (
    create_access_token,
    hash_password,
    verify_password,
)
from app.db.models.User import User

logger = logging.getLogger(__name__)


class AuthService:
    def __init__(self, session: Session):
        self.session = session

    def register(self, username: str, email: str, password: str) -> str:
        """Create a new user and return an access token."""
        normalized_email = email.strip().lower()

        user = User(
            username=username,
            email=normalized_email,
            password_hash=hash_password(password),
        )

        try:
            # Avoid beginning a new transaction if one is already active
            if not self.session.in_transaction():
                with self.session.begin():
                    self.session.add(user)
                    # Ensure PK is assigned before token creation
                    self.session.flush()
                    return create_access_token(user.user_id)
            else:
                # Running inside an existing transaction (e.g., tests)
                self.session.add(user)
                self.session.flush()
                return create_access_token(user.user_id)

        except IntegrityError:
            logger.debug(
                "Registration failed due to duplicate email: %s",
                normalized_email,
            )
            raise ValueError("Email already registered")

    def login(self, email: str, password: str) -> str:
        normalized_email = email.strip().lower()

        user = (
            self.session.query(User)
            .filter_by(email=normalized_email)
            .first()
        )

        if user is None or not verify_password(password, user.password_hash):
            logger.debug(
                "Failed login attempt for email: %s",
                normalized_email,
            )
            raise ValueError("Invalid credentials")

        return create_access_token(user.user_id)
