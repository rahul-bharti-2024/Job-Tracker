# from fastapi import FastAPI
# from app.api.routes.job_applications import router as job_applications_router
# from app.api.routes import auth


# app= FastAPI(title= "Job Tracker MVP")

# app.include_router(auth.router)
# app.include_router(job_applications_router)
from fastapi import FastAPI
from contextlib import asynccontextmanager
import logging

from app.db.session import init_engine, build_postgres_url, dispose_engine
from app.api.routes import auth, job_applications


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 🔵 Startup
    try:
        init_engine(build_postgres_url())
        logging.info("Database engine initialized")
        yield
    except Exception:
        logging.exception("Failed to initialize database engine")
        raise
    finally:
        # 🔵 Shutdown - dispose engine if initialized
        try:
            dispose_engine()
            logging.info("Database engine disposed")
        except Exception:
            logging.exception("Error disposing database engine")


app = FastAPI(lifespan=lifespan)

app.include_router(auth.router)
app.include_router(job_applications.router)
