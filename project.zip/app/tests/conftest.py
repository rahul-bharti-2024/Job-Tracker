import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT))

import pytest
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from app.main import app as fastapi_app
from app.db.session import get_session
from app.db.models.base import Base
import app.db.models
from app.db.models.Company import Company

# -------------------------------------------------
# Shared in-memory DB
# -------------------------------------------------
engine = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)

TestingSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

# -------------------------------------------------
# Create tables ONCE per test
# -------------------------------------------------
@pytest.fixture(scope="function")
def db():
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)

# -------------------------------------------------
# Override FastAPI session
# -------------------------------------------------
@pytest.fixture(scope="function")
def client(db):
    def override_get_session():
        try:
            yield db
        finally:
            # Expire objects in the session so subsequent requests see committed state
            try:
                db.expire_all()
            except Exception:
                # fallback to safe close if expire_all fails
                db.close()

    fastapi_app.dependency_overrides[get_session] = override_get_session

    with TestClient(fastapi_app) as c:
        yield c

    fastapi_app.dependency_overrides.clear()

# -------------------------------------------------
# Company fixture
# -------------------------------------------------
@pytest.fixture(scope="function")
def company(db):
    company = Company(name="Test Company")
    db.add(company)
    db.commit()
    db.refresh(company)
    return company
