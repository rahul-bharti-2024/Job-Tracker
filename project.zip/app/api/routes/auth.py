from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_session
from app.api.schemas.auth import UserCreate, UserLogin, TokenResponse
from app.services.AuthService import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post(
    "/register",
    response_model=TokenResponse,
    status_code=status.HTTP_201_CREATED,
)
def register(
    request: UserCreate,
    session: Session = Depends(get_session),
):
    service = AuthService(session)
    try:
        token = service.register(
            username=request.username,
            email=request.email,
            password=request.password,
        )
        return {
            "access_token": token,
            "token_type": "bearer",
        }

    except ValueError as e:
        # Email already registered
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e),
        )


@router.post(
    "/login",
    response_model=TokenResponse,
)
def login(
    request: UserLogin,
    session: Session = Depends(get_session),
):
    service = AuthService(session)
    try:
        token = service.login(
            email=request.email,
            password=request.password,
        )
        return {
            "access_token": token,
            "token_type": "bearer",
        }

    except ValueError:
        # Do not leak whether email exists
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )
